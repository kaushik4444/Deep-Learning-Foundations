Exercise 2

Follow the instructions in Forward.ipynb and implement the functions in modules.py. Submit your code by uploading the implemented modules.py file to moodle.
